
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent }   from './app.component';
import {NotesComponent} from "./notes.component";
import {HttpModule} from "@angular/http";
import {SectionsComponent} from "./sections.component";
import {DragulaModule} from "ng2-dragula";
import {SectionFilterPipe} from "./sectionFilter.pipe";
import {RouterModule, Routes} from "@angular/router";
import {PageNotFoundComponent} from "./pageNotFound.component";
import {NotesEditorComponent} from "./notesEditor.component";
import {ViewSectionComponent} from "./viewSection.component";
import {NotesServerService} from "./services/notesServer";
import {CanDeactivateNote} from "./services/canDeactivateNote";
import {UserFormComponent} from "./userForm.component";
import {EqualToValidator} from "./directives/EqualToValidator";
import {UserUniqueValidator} from "./directives/UserUniqueValidator";
import {LoginFormComponent} from "./loginForm.component";
import {LoginService} from "./services/LoginService";

const appRoutes: Routes = [
  { path: '', component: NotesEditorComponent, canDeactivate: [CanDeactivateNote] },
  { path: 'register', component: UserFormComponent },
  { path: 'viewSection/:name', component: ViewSectionComponent },
  { path: ':name', component: NotesEditorComponent, canDeactivate: [CanDeactivateNote] },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports:      [ BrowserModule,
                  RouterModule.forRoot(appRoutes),
                  FormsModule, HttpModule, DragulaModule ],
  providers:    [ NotesServerService, CanDeactivateNote, LoginService ],
  declarations: [ AppComponent,
                  NotesComponent,
                  SectionsComponent, SectionFilterPipe,
                  PageNotFoundComponent, NotesEditorComponent,
                  ViewSectionComponent, UserFormComponent,
                  EqualToValidator, UserUniqueValidator,
                  LoginFormComponent
  ],
  bootstrap:    [ AppComponent ],

})
export class AppModule { }
