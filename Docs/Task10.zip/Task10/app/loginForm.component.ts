import {Component, ViewChild} from "@angular/core";
import {Router, ActivatedRoute, Params} from "@angular/router";
import {NotesComponent} from "./notes.component";
import {LoginService, LoginUser} from "./services/LoginService";
@Component({
    selector: 'login-form',
    templateUrl: 'app/loginForm.component.html'
})
export class LoginFormComponent {
    userForm: LoginUser = new LoginUser();
    failedLogin: boolean;

    constructor(private loginService: LoginService, private router: Router) {}

    login() {
        this.loginService.login(this.userForm)
            .subscribe(res=>res?this.onSuccessLogin():this.onFailLogin());
    }

    logout() {
        this.loginService.logout().subscribe(res=>this.onLogout());
    }

    get loggedIn() {
        return this.loginService.loggedIn;
    }

    onSuccessLogin() {
        this.router.navigateByUrl("/");
    }

    onFailLogin() {
        this.failedLogin = true;
        setTimeout(() => this.failedLogin = false, 1000);
    }

    onLogout() {
        this.router.navigateByUrl("/");
    }
}

