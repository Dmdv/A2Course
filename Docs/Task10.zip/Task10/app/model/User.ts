export class User {
    userName:string;
    password: string;
    password2: string;
    subscribe: boolean;
    email: string;
    dateOfBirth: Date;
}