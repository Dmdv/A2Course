import {Component, Input, Inject} from '@angular/core';
import {Http, URLSearchParams} from '@angular/http';

import 'rxjs/add/operator/toPromise';
import 'rxjs/Rx';
import {NotesServerService} from "./services/notesServer";

@Component({
    selector: 'notes',
    templateUrl: 'app/notes.component.html'
})
export class NotesComponent {
    notes: Note[];
    text: string;
    @Input() section: string;

    private notesUrl = 'notes';  // URL to web api

    constructor(private http:Http, private notesServer: NotesServerService) {
    }

    ngOnChanges() {
        this.readNotes();
    }

    readNotes() {
        this.notesServer.getNotes(this.section).subscribe(notes=>{
            this.notes=notes
        });
    }

    addNote(note:Note) {
        this.http.post(this.notesUrl, note).toPromise()
            .then(response => {
                console.log("note sent, response", response);
                this.readNotes();
            } );
    }

    add() {
        if (!this.text) return;
        let note = { text: this.text, section: this.section };
        this.notes.push(note);
        this.text = "";
        this.addNote(note);
    }

    remove(id:string) {
        let params: URLSearchParams = new URLSearchParams();
        params.set('id', id);
        this.http.delete(this.notesUrl, { search: params })
            .toPromise()
            .then(response => {
                console.log(
                    `note with id {{id}} removed, response`, response);
                this.readNotes();
            });
    }

}

export interface Note {
    text: string;
}

