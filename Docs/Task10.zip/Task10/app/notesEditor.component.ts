import {Component, ViewChild} from "@angular/core";
import {Router, ActivatedRoute, Params} from "@angular/router";
import {NotesComponent} from "./notes.component";
@Component({
  template: `
    <div class="container">
      <div class="row">
          <div class="col-md-8">
              <notes [section]="section"></notes>
          </div>
          <div class="col-md-4">
              <sections [section]="section" (sectionChanged)="setSection($event)"></sections>
          </div>
      </div>
    </div>
  `
})
export class NotesEditorComponent {
  section: string;
  @ViewChild(NotesComponent) notesComponent:NotesComponent;

  constructor(private route: ActivatedRoute, private router: Router) {
    this.route.params
        .map(params=>params["name"])
        .subscribe(section=>{
          console.log("Subscription to name route!");
          this.section=section
        });

    //router.
  }

  ngOnDestroy() {
    console.log("NotesEditorComponent destroyed");
  }

  setSection(section:string) {
    //  this.section = section;
    this.router.navigate([section]);
  }

}
