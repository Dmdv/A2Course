import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import {Note} from "../notes.component";
import {URLSearchParams, Http} from "@angular/http";

@Injectable()
export class NotesServerService {
    private notesUrl = 'notes';  // URL to web api

    constructor(private http: Http) { }

    getNotes(section): Observable<Note[]> {
        let params: URLSearchParams = new URLSearchParams();
        params.set('section', section);
        return this.http.get(this.notesUrl, {search:params})
            .map(response => response.json() as Note[]);
    }

}