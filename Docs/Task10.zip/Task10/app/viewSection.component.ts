import {Component} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {NotesServerService} from "./services/notesServer";
import {Note} from "./notes.component";
import {Observable, Subscriber} from "rxjs";

@Component({
    template: `
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-primary ">
                <div class="panel-heading">
                    <h3 class="panel-title">{{section}}</h3>
                </div>
                <ul class="list-group">
                    <li *ngFor="let note of notes$ | async"
                        class="list-group-item">{{note.text}}</li>
                </ul>
            </div>
        </div>
    `
})
export class ViewSectionComponent {
    section: string;
    notes: Note[];
    notes$: Observable<Note[]>;

    constructor(private route: ActivatedRoute, private router: Router,
        private noteServer: NotesServerService) {
    }

    getNotes() {
        return this.noteServer.getNotes(this.section);
    }

    ngOnInit() {
        this.section = this.route.snapshot.params["name"];
        this.notes$ = this.getNotes();
        //this.notes$.subscribe(notes=>this.notes=notes);
    }
}
