npm install

npm start

