var express = require('express');
var app = express();
var path = require('path');
var session = require('express-session');
var bodyParser = require('body-parser')
var fs = require('fs');

var root = __dirname + '/..'
app.use(express.static(root,{extensions:['html','js','css']}));
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

app.use(session({
    secret: 'angular_tutorial',
    resave: true,
    saveUninitialized: true,
}));

var Db = require('mongodb').Db;
var Connection = require('mongodb').Connection;
var Server = require('mongodb').Server;
var ObjectID = require('mongodb').ObjectID;

var db = new Db('tutor', new Server("localhost", 27017, {safe: true}, {auto_reconnect: true}, {}));
db.open(function(){
    console.log("mongo db is opened!");

    db.collection('notes', function(error, notes) {
        db.notes = notes;
    });

    db.collection('sections', function(error, sections) {
        db.sections = sections;
    });

    db.collection('users', function(error, users) {
        db.users = users;
    });
});

app.get("/sections", function(req,res) {
    var userName = req.session.userName || "demo";
    db.users.find({userName:userName})
        .toArray(function(err, items) {
            var user = items[0];
            res.send(user.sections||[]);
        });
});


app.get("/checkUserUnique", function(req,res) {
    var user = req.query.user;
    console.log("checkUserUnique for user ",user, user.length>2);
    if (user.length>2) res.send(true);
    else res.send(false);
});

app.post("/sections/replace", function(req,res) {
    console.log("SECTIONS REPLACE:",req.body);
    var userName = req.session.userName || "demo";
    db.users.update({userName:userName},
        {$set:{sections:req.body}},
        function() {
            res.end();
        });
});



function setUserQuery(req) {
    req.query.userName = req.session.userName || "demo";
}

app.get("/notes", function(req,res) {
    setUserQuery(req);
    db.notes.find(req.query)
        .toArray(function(err, items) {
            res.send(items);
        });
});

app.post("/notes", function(req,res) {
    req.body.userName =  req.session.userName || "demo";
    db.notes.insert(req.body);
    console.log(req.body);
    res.end();
});

app.delete("/notes", function(req,res) {
    var id = new ObjectID(req.query.id);
    db.notes.remove({_id: id}, function(err){
        if (err) {
            console.log(err);
            res.send("Failed");
        } else {
            res.send("Success");
        }
    })
});
app.post("/users", function(req,res) {
    console.log(req.body);
    db.users.insert(req.body, function(resp) {
        req.session.userName = req.body.name;
        console.log("inserted user", req.body.name);
        res.end();
    });
});
app.get("/logout", function(req, res) {
    req.session.userName = null;
    res.end();
});

app.post("/login", function(req,res) {
    db.users.find(
        {userName:req.body.username,
            password:req.body.password})
        .toArray(function(err, items) {
            if (items.length>0) {
                req.session.userName = req.body.username;
            }
            res.send(items.length>0);
        });
});

app.get("*", function(req, res, next) {
    res.sendFile('index.html', { root : root });
});

// app.get("/viewSection/*", function(req, res, next) {
//     var url = req.originalUrl.replace("/viewSection/","");
//     if (url.match("app/*|node_modules/*|systemjs.config.js|css/*|fonts/*") )
//         res.sendFile(url, { root : root });
//     else res.sendFile('index.html', { root : root });
// });

app.listen(3000);
